/*
	Sound, finally.

	Check out the p5 reference page: http://p5js.org/reference.
	Check out the p5.sound reference page: http://p5js.org/reference/#/libraries/p5.sound.

	For loading and manipulating sound, you need to include p5.sound in index.html!
*/

function setup() {

}

function draw() {

}
