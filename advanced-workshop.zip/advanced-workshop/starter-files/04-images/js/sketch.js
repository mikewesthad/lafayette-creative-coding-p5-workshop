/*
	Images!

	Check out the p5 reference page: http://p5js.org/reference.

	New p5 variables and functions:
		preload()
		loadImage(...)

	p5.image variables and functions:
		img.resize(...)
		img.loadPixels(...)
		img.get(...)
*/

function setup() {

}

function draw() {
	
}
