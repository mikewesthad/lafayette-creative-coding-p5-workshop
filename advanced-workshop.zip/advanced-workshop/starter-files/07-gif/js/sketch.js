/* globals loadGif */
