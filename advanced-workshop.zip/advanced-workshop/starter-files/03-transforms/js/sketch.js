/*
	Transformation - translate, rotate, scale

    Check out the p5 reference page: http://p5js.org/reference.

	New p5 variables and functions:
		push() & pop()
		translate(...)
		rotate(...)
		scale(...)
		angleMode(...)
		rectMode(...)
		dist(...)
		map(...)

	See index.html for disabling the right click menu.
*/

// Any code that you put inside of setup runs ONCE at the start of the sketch
function setup() {

}

// After setup is run, any code that you put inside of draw runs REPEATEDLY at
// 60 frames per second
function draw() {

}
